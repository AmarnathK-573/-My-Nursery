package com.sprint1.plantnursery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapgSprint1PlantNurseryApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapgSprint1PlantNurseryApplication.class, args);
		System.out.println("OnlinePlantNursery-Master Server Started");
	}

}
