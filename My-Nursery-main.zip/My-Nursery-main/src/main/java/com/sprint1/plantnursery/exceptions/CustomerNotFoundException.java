package com.sprint1.plantnursery.exceptions;

/*Controller Class for Customer Controller*/

public class CustomerNotFoundException extends Exception {
	public CustomerNotFoundException(String s) {
		super(s);
	}
}
