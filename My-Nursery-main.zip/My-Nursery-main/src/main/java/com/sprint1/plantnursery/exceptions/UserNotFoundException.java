package com.sprint1.plantnursery.exceptions;

/*Controller Class for Customer Controller*/

public class UserNotFoundException extends Exception{
	public UserNotFoundException(String s) {
		super(s);
	}
}
