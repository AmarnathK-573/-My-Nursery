package com.sprint1.plantnursery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapgSprint1PlantNurseryApplicationTests {

	@Test
	void contextLoads() {
	}

}
